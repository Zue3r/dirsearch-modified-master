import requests
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from hurry.filesize import size
from concurrent.futures import ThreadPoolExecutor

requests.packages.urllib3.disable_warnings()

logging.basicConfig(level=logging.WARNING, format="%(message)s")

class BackupFileScanner:
    def __init__(self, url=None):
        self.url = url[0]
        self.urllist = []
        self.max_threads = 25
        self.suffix_format = ['.zip', '.rar', '.tar.gz', '.tgz', '.tar.bz2', '.tar', '.jar', '.war', '.7z', '.bak',
                              '.sql', '.gz', '.sql.gz', '.tar.tgz', '.backup', '.txt', '.mdb', '.config', '.log',
                              '.old', '.xml', '.properties', '.conf', '.md']
        self.info_dic = self.generate_info_dic()  # 前缀 + 后缀 组合式生成固定字典
        self.dispatcher(self.info_dic)  # 只传递 info_dic，而不是 self

    def dispatcher(self, dic):
        url = self.urlcheck(self.url.strip())
        self.urllist = self.generate_check_url(url, self.info_dic)
        # print(self.urllist)
        self.run_scans(self.urllist)

    def generate_info_dic(self):
        tmp_info_dic = ['1', '127.0.0.1', 'localhost', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018',
                        '2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026', 'admin', 'archive', 'asp', 'aspx',
                        'auth', 'back', 'backup', 'backups', 'bak', 'bbs', 'bin', 'clients', 'code', 'com', 'customers',
                        'dat', 'data', 'database', 'db', 'dump', 'engine', 'error_log', 'files', 'forum', 'home',
                        'html', 'index', 'joomla', 'js', 'jsp', 'local', 'localhost', 'master', 'media', 'members',
                        'my', 'mysql', 'new', 'old', 'orders', 'php', 'sales', 'site', 'sql', 'store', 'tar', 'test',
                        'yuanma','beifen', 'admin' ,'user', 'users', 'vb', 'web', 'website', 'wordpress', 'wp', 'www', 'www1', 'www2', 'wwwroot', 'root', 'log', 'tmp']
        info_dic = []
        for a in tmp_info_dic:
            for b in self.suffix_format:
                info_dic.append(a + b)
        return info_dic

    def urlcheck(self, target):
        if target.startswith('http://') or target.startswith('https://'):
            return target if target.endswith('/') else target + '/'
        else:
            line = 'http://' + target
            return line if line.endswith('/') else line + '/'

    def generate_check_url(self, url, dic):
        check_urllist = []
        cport = None
        current_info_dic = deepcopy(dic)

        if url.startswith('http://'):
            ucp = url.lstrip('http://')
        elif url.startswith('https://'):
            ucp = url.lstrip('https://')
        if '/' in ucp:
            ucp = ucp.split('/')[0]
        if ':' in ucp:
            cport = ucp.split(':')[1]
            ucp = ucp.split(':')[0]
            www1 = ucp.split('.')
        else:
            www1 = ucp.split('.')
        wwwlen = len(www1)
        wwwhost = ''
        for i in range(1, wwwlen):
            wwwhost += www1[i]

        domainDic = [ucp, ucp.replace('.', ''), ucp.replace('.', '_'), wwwhost, ucp.split('.', 1)[-1],
                     (ucp.split('.', 1)[1]).replace('.', '_'), www1[0], www1[1]]
        domainDic = list(set(domainDic))

        for s in self.suffix_format:
            for d in domainDic:
                current_info_dic.extend([d + s])
        current_info_dic = set(dic + [d + s for d in domainDic for s in self.suffix_format])
        current_info_dic = list(set(current_info_dic))
        # print(current_info_dic)
        for info in current_info_dic:
            current_url = str(url) + str(info)
            check_urllist.append(current_url)
        return check_urllist

    def run_scans(self, check_urllist):
        with ThreadPoolExecutor(self.max_threads) as executor:
            futures = {executor.submit(self.vuln, url): url for url in check_urllist}
            try:
                for future in as_completed(futures):
                    url = futures[future]
                    try:
                        future.result()  # This will raise an exception if the thread encountered one
                    except Exception as e:
                        logging.error(f"Error scanning {url}: {e}")
                        executor.shutdown(wait=False)
                        os._exit(1)
            except KeyboardInterrupt:
                logging.warning("Bye.")
                # Properly shut down the executor
                executor.shutdown(wait=False)
                os._exit(1)  # Force terminate the process

    def vuln(self, urltarget):
        try:
            r = requests.get(urltarget, verify=False, stream=True)
            if r.status_code == 200 and all(x not in r.headers.get('Content-Type') for x in
                                            ['html', 'image', 'xml', 'text', 'json', 'javascript']):
                rarsize = size(int(r.headers.get('Content-Length', 0)))
                if int(rarsize[:-1]) >= 0:
                    logging.warning('[ success ] {}  size:{}'.format(urltarget, rarsize))
        except Exception as e:
            logging.warning('[ fail ] {}'.format(urltarget))

# 运行时需要创建 BackupFileScanner 实例
if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python script.py <url>")
        sys.exit(1)
    url = [sys.argv[1]]
    scanner = BackupFileScanner(url=url)